using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;

[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyTitle("IntraLattice")]
[assembly: AssemblyDescription("Set of components for generating lattice structures within a design space.")]
[assembly: AssemblyProduct("IntraLattice")]
[assembly: AssemblyCopyright("Copyright © ADML 2015")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("a9172bef-6e73-4cad-b18b-4072973fa4f6")]
[assembly: AssemblyFileVersion("0.7.5")]
[assembly: AssemblyVersion("0.7.5.0")]
