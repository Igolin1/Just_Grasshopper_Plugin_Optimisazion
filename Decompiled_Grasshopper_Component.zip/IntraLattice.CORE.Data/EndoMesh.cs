namespace IntraLattice.CORE.Data;

internal class EndoMesh
{
}
