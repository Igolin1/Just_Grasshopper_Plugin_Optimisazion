namespace IntraLattice.CORE.Data;

public enum LatticeNodeState
{
	Outside,
	Inside,
	Boundary
}
